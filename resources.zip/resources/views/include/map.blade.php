@desktop
<div id="map" class="map-wrapper clearfix hidden-xs">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-4 col-lg-3 col-sm-4">
                <?php echo setting('site.phonecontacts'); ?>
            </div>
        </div>
    </div>
    <div class="container-fluid">
        <div class="row">
            <div class="map-direction">
                <?php echo setting('site.map'); ?>
            </div>
        </div>
    </div>
</div>
@enddesktop
