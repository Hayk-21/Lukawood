<html>
<head></head>
<body>
<div style="display: table; width: 100%; text-align: center; height: 40px; background: #68A4C4; color: #fff; font-family: 'Open Sans', Arial, sans-serif; font-size: 14px; font-weight: bold;">
    <div style="display: table-cell; vertical-align: middle;">Новое сообщение от клиента {{ $sender['Feedbacks']['name'] }}!</div>
</div>

<div style="display: table; width: 100%; text-align: center; height: 40px; background: #68A4C4; color: #fff; font-family: 'Open Sans', Arial, sans-serif; font-size: 14px; font-weight: bold;">
    <div style="display: table-cell; vertical-align: middle;">Телефон: {{ $sender['Feedbacks']['phone'] }}</div>
</div>
</body>
</html>