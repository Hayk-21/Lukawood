window.lightbox = require('lightbox2');
window.Owl = require('owl.carousel');